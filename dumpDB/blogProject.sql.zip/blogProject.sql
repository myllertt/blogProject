-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 12-Nov-2021 às 17:17
-- Versão do servidor: 8.0.27
-- versão do PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `blogProject`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ComentariosPosts`
--

CREATE TABLE `ComentariosPosts` (
  `id` bigint NOT NULL COMMENT 'Id do comentário',
  `conteudo` varchar(512) NOT NULL COMMENT 'Conteúdo do comentário',
  `tipo` enum('U','A') NOT NULL COMMENT 'Tipo de comentário. U = Usuário site, A = Usuário Administrador',
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data em que o registro foi cadastrado',
  `idUsSite` int DEFAULT NULL COMMENT '(Relação com a tabela. UsuariosSite.id) Id do usuário(site) caso tenha sido um usuário do tipo. Neste caso ficará nulo se o mesmo não for deste deste tipo.',
  `idUsAdmin` int DEFAULT NULL COMMENT '(Relação com a tabela. UsuariosAdmin.id) Id do usuário(Admin) caso tenha sido um usuário do tipo. Neste caso ficará nulo se o mesmo não for deste deste tipo.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `Permissoes`
--

CREATE TABLE `Permissoes` (
  `codigo` varchar(64) NOT NULL COMMENT 'Código de referência da permissão.',
  `descricao` varchar(128) DEFAULT NULL COMMENT 'Descrição da permissão.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `PermissoesUsuariosAdmin`
--

CREATE TABLE `PermissoesUsuariosAdmin` (
  `idUsuario` int NOT NULL COMMENT '(Relação com a tabela. UsuariosAdmin.id) Id do usuário admin',
  `codigo` varchar(64) NOT NULL COMMENT '(Relação com a tabela. Permissoes.codigo) Codigo respectivo da permissão'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `Posts`
--

CREATE TABLE `Posts` (
  `id` int NOT NULL COMMENT 'Id da postagem',
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT 'Status da postagem. 1 = Ativado, 0 = Desativado',
  `titulo` varchar(128) NOT NULL COMMENT 'Título da postagem',
  `conteudo` text NOT NULL COMMENT 'Conteúdo da postagem',
  `idUsuario` int NOT NULL COMMENT '(Relação com a tabela. UsuariosAdmin.id). Id do usuário responsável pela postagem.',
  `dataCad` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data em que o registro foi cadastrado',
  `dataAt` datetime DEFAULT NULL COMMENT 'Data em que o registro foi atualizado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `Posts`
--

INSERT INTO `Posts` (`id`, `status`, `titulo`, `conteudo`, `idUsuario`, `dataCad`, `dataAt`) VALUES
(1, '1', 'O que há de novo no PHP8', '	Augue congue imperdiet fusce pharetra integer mi aliquet congue, mollis euismod blandit proin nisl conubia placerat, duis sagittis fusce suscipit pretium etiam sed. nunc platea aliquet sociosqu vel nam metus rhoncus eu, etiam a porta eget praesent consectetur faucibus ultricies ipsum, netus pulvinar dictum consequat fames nisl platea. quisque non vel sem porta rutrum netus hendrerit, habitasse class erat lacus bibendum adipiscing interdum torquent, ante metus quisque bibendum molestie primis. nisi senectus velit quisque bibendum nulla sollicitudin nibh eleifend fusce, viverra dapibus accumsan malesuada velit fermentum ac himenaeos sed, nec viverra ullamcorper luctus lacinia duis tempor vivamus. \n\n	Hendrerit hac augue erat risus lectus elit himenaeos tristique, pharetra torquent porta leo id orci quisque accumsan, consectetur justo tempus in aptent lectus suscipit. sodales felis maecenas augue nostra nisi auctor tristique praesent consequat vehicula eu duis etiam, quam pharetra arcu aenean magna fames vehicula bibendum metus pretium class lacinia. arcu aenean curae cras lacus eu purus mauris sem, fusce sit sodales aliquet pharetra eleifend inceptos amet, potenti nunc velit ac imperdiet rutrum diam. phasellus ante nam ac donec commodo aenean interdum hac nullam id, molestie class luctus eros vulputate donec in ornare blandit. \n\n	Arcu feugiat sem elit inceptos quisque porttitor quam mauris proin tellus aenean, diam purus ut sit ipsum purus volutpat taciti facilisis litora. morbi nullam aliquet facilisis tortor pharetra potenti litora quisque nisi nullam at, nostra etiam ad phasellus velit et fusce molestie aliquam. maecenas nec congue pharetra magna feugiat senectus proin, habitant neque nostra aliquam iaculis vel duis enim, sapien rhoncus torquent viverra quisque iaculis. eleifend est velit fermentum auctor porta sit sodales fusce ante, porta vivamus scelerisque libero ut litora magna. tristique sagittis nullam quisque tempus aliquam justo torquent ornare id, hac nullam duis interdum tristique venenatis himenaeos consequat vel donec, cras lacus ut donec curae quisque vel augue. \n\n	Metus tristique nulla sapien porta sollicitudin tellus, pulvinar congue malesuada ante lacinia volutpat, in curabitur sagittis varius risus. quis posuere conubia libero senectus ligula bibendum purus malesuada quis risus habitant rhoncus velit dictumst quisque, ad taciti bibendum nulla morbi quis pretium euismod dictumst euismod commodo cursus quis. etiam sociosqu fusce facilisis tortor purus erat cursus, nostra enim phasellus praesent sodales pellentesque, nunc himenaeos adipiscing et venenatis vel. nisl habitant molestie sem nisi fringilla fames, primis lacus risus quisque bibendum justo, tempus duis eget dictumst suscipit. feugiat ut nisl est arcu vitae, netus tempor quisque tellus, lacinia porta luctus maecenas. ', 1, '2021-11-10 15:29:03', NULL),
(2, '1', 'Clássicos da informática', '	Consectetur aenean purus feugiat ligula tortor vel facilisis volutpat venenatis auctor euismod feugiat id placerat turpis ac aenean, justo ipsum consequat tempus risus donec ac sed lectus fusce etiam platea ac pulvinar enim ultricies. tristique euismod per ullamcorper eu elit nisi lacinia aptent, congue vulputate tortor leo eget lacinia sit, dolor molestie ac habitant tellus bibendum primis nec, imperdiet ad etiam fringilla fames leo. neque ut litora consequat aliquam pretium enim cursus ut, mi conubia donec nostra mattis quisque amet, sollicitudin malesuada class nullam eu nulla augue. cubilia consequat interdum erat tincidunt egestas urna tempor lorem, nunc imperdiet sodales habitasse torquent mi eleifend malesuada, curabitur primis convallis inceptos sed ut fermentum. \r\n\r\n	Rhoncus quis lacinia vehicula orci augue mi erat auctor pretium rhoncus pharetra, proin rutrum orci fringilla scelerisque dolor ad sodales velit quis hendrerit, velit odio vehicula potenti blandit pharetra morbi purus curabitur dapibus. platea nulla commodo placerat vulputate sed porta tincidunt quis consequat lectus curabitur sapien, lobortis quisque tincidunt hac amet eu cursus blandit pretium pellentesque sem. erat nec ipsum elit fames proin accumsan taciti tempor sem accumsan, nisl ornare pharetra facilisis etiam ornare rhoncus ligula inceptos lobortis pretium, himenaeos massa duis posuere torquent faucibus adipiscing luctus convallis. vivamus viverra ornare felis duis venenatis amet eget leo lacus amet, mattis consectetur diam amet gravida adipiscing suscipit purus ut. \r\n\r\n	Primis aliquam lectus imperdiet feugiat nam varius, class scelerisque tristique conubia viverra quisque placerat, aliquet non suspendisse aliquam accumsan. sed curabitur nec nunc venenatis class suspendisse cursus pulvinar cras tortor, pulvinar purus netus ad aliquet morbi sollicitudin ut hendrerit, aliquam scelerisque malesuada massa vivamus vehicula ut consectetur ultrices. netus mi semper integer ad accumsan placerat sapien maecenas quam, sodales pulvinar cursus sagittis leo aliquet ac rutrum accumsan, venenatis fringilla velit odio est ullamcorper orci blandit. accumsan hendrerit egestas maecenas hendrerit lacus vivamus mollis elementum neque tortor feugiat, proin vitae luctus purus urna quisque volutpat vivamus nulla vestibulum sociosqu ut, convallis pharetra etiam laoreet per mauris purus vehicula odio non. \r\n\r\n	Elementum porttitor pretium primis orci interdum purus habitasse hendrerit aenean, vehicula scelerisque gravida convallis malesuada rhoncus himenaeos habitant, dictum mollis lacus sociosqu convallis tellus odio tristique. pulvinar accumsan fusce ornare non donec augue accumsan, et facilisis sed libero etiam massa vestibulum nunc, lacinia dictum sem pretium dictumst lorem. diam luctus dictumst lobortis auctor convallis consequat vel adipiscing, nisi integer suscipit congue ut est molestie suscipit, viverra dui aenean felis laoreet nunc nec. ', 1, '2021-11-10 15:29:42', NULL),
(3, '1', 'O que foi o BUG do milênio?', '	Bibendum sociosqu facilisis tempus et massa posuere venenatis est, in massa consequat venenatis per in morbi, varius mollis phasellus donec condimentum gravida molestie. lobortis hac habitasse facilisis dapibus sagittis a class diam habitasse, laoreet leo adipiscing felis ullamcorper scelerisque fringilla non, eleifend congue massa aliquam libero nunc id eleifend. interdum cras vitae libero sed magna lacus venenatis lectus, quisque aliquam cras tincidunt a phasellus curabitur, diam posuere ornare torquent et porttitor cras. himenaeos volutpat tristique enim risus sodales interdum rhoncus vitae amet erat curae, eleifend sem diam tincidunt risus dapibus nam dapibus dictumst donec ultrices, phasellus quis ultrices ac phasellus aliquam eget luctus habitant class. \r\n\r\n	Platea aenean scelerisque taciti donec venenatis aliquam gravida nibh at aliquet, et mauris faucibus dolor interdum lacus semper fusce nostra, varius purus litora non consequat fermentum varius nostra etiam. ullamcorper aliquam conubia pharetra pellentesque potenti fermentum quis sapien curabitur tempor viverra, curabitur consequat primis dapibus cras ullamcorper rhoncus potenti lectus potenti, pharetra venenatis molestie curabitur magna sed cras eleifend ut senectus. donec dolor sagittis odio dapibus cubilia felis dictumst nisi integer aliquam tempor netus, habitasse nulla maecenas tristique accumsan sociosqu arcu fermentum hendrerit auctor massa. euismod aenean molestie maecenas phasellus lobortis viverra quisque velit, cubilia aliquam vehicula torquent venenatis lorem aliquet semper, pharetra nec aliquet pharetra etiam ligula maecenas. \r\n\r\n	Tellus iaculis magna est sed urna elit imperdiet inceptos morbi nisi, auctor eleifend curabitur quam sagittis vestibulum sodales ultricies justo neque lectus, libero at eleifend purus rhoncus aenean class neque cursus. euismod fames eleifend sagittis facilisis semper auctor mollis condimentum lobortis taciti neque purus dictum, non ornare augue lacus duis nisi laoreet phasellus ac ut felis malesuada. velit eget libero sagittis morbi varius facilisis mi a, aliquet tempus nibh mattis aenean condimentum phasellus, netus aenean nunc rhoncus nam eleifend justo. nunc proin rutrum felis mauris aenean arcu nulla odio etiam, diam habitant auctor proin augue egestas eros aenean cras placerat, etiam pellentesque gravida cras erat adipiscing pretium etiam. \r\n\r\n	At pretium etiam sapien orci neque auctor tincidunt egestas risus diam placerat massa mattis habitant vitae a, condimentum litora congue mauris porta nullam lobortis morbi molestie torquent elementum ultricies nulla sollicitudin habitasse. sed urna habitant aptent ipsum himenaeos habitasse nec dolor, a sodales tempus augue torquent praesent inceptos, mollis sollicitudin interdum molestie adipiscing ut litora. blandit sollicitudin nec non nunc sapien luctus urna eros, metus magna phasellus tellus viverra feugiat ad, taciti justo taciti aliquam tincidunt ligula diam. ', 1, '2021-11-10 15:30:33', '2021-11-10 15:29:43'),
(4, '1', 'Novidades NodeJs', '	Phasellus tristique lorem conubia augue posuere lectus magna, sagittis vestibulum mollis bibendum dictumst curae, placerat platea eros neque commodo porta. dictumst habitasse neque lobortis enim facilisis aliquam, nibh litora potenti netus vestibulum, aliquam turpis feugiat taciti habitasse. mauris nec convallis blandit rutrum augue curabitur lacinia phasellus sit, torquent tellus facilisis laoreet imperdiet class ornare lacinia scelerisque, sem vivamus augue proin justo etiam vel pulvinar. dolor fames sit hac etiam sit tincidunt nunc, eros enim iaculis fames cubilia vivamus quisque, pellentesque scelerisque nisl tempor sem malesuada. mollis curabitur amet proin amet tortor ut, nullam ad phasellus nisl praesent dictumst, in cras conubia posuere nec. \r\n\r\n	Dolor facilisis accumsan lacinia venenatis potenti sem hac pellentesque laoreet, venenatis facilisis accumsan primis neque dapibus non per adipiscing, lobortis eros duis orci augue integer sapien ante. augue leo porttitor habitant fringilla nisi sagittis ipsum lacus lectus, suspendisse maecenas porttitor class id aptent in sit potenti, sociosqu metus cubilia sed pellentesque sed duis risus. etiam tellus accumsan ut porta etiam euismod placerat nulla inceptos habitasse porttitor curabitur scelerisque pretium, volutpat dictum rhoncus torquent condimentum cras quisque viverra pulvinar orci gravida tempus molestie. aenean netus condimentum senectus nullam auctor faucibus ante ipsum, integer nunc quis varius curae hac. \r\n\r\n	Sem sagittis nunc morbi porttitor mi porta ornare vivamus egestas platea leo, cubilia nec faucibus ullamcorper auctor orci donec hendrerit consequat etiam vivamus dictum, vitae leo vulputate maecenas quisque nam integer himenaeos conubia ante. tristique lobortis purus platea bibendum duis massa ac malesuada eros enim risus sed ipsum et, nisl conubia rhoncus blandit accumsan tempus curabitur sit phasellus platea rutrum nibh posuere. consectetur augue aliquam fusce potenti consectetur molestie imperdiet congue nulla aliquam, habitant magna non integer netus arcu curae justo malesuada varius, ut phasellus platea sodales dapibus torquent orci pulvinar elit. \r\n\r\n	Eleifend fusce non congue varius interdum platea tempus porta euismod egestas, eleifend nibh aliquam porttitor mauris pellentesque phasellus vivamus dictum, massa congue dolor maecenas pellentesque dui felis dolor laoreet. consectetur eros ornare tempor auctor platea malesuada quam libero sodales, netus duis a nam ac facilisis mi amet, lacinia cras torquent felis feugiat amet lacinia fringilla suspendisse, diam cras adipiscing convallis donec sodales suspendisse. metus himenaeos maecenas nisi nunc accumsan commodo placerat, rutrum etiam vulputate cursus sit platea scelerisque orci, litora malesuada venenatis pretium ut aliquam. metus tortor nostra pharetra nunc litora hac class adipiscing, ac faucibus nulla primis luctus porttitor euismod, purus gravida habitasse dui sapien sociosqu nulla. ', 1, '2021-11-10 15:31:15', NULL),
(5, '1', 'Saiba quem foram os criadores da famosa linguagem c', '	Laoreet suspendisse cubilia nisl quam aenean sodales ut, tristique id vel luctus curabitur netus ad sodales, habitasse nostra ultrices cras nulla porta. integer ac suspendisse dui ultrices praesent quam ad vivamus, interdum aliquam diam tortor aliquam auctor vivamus fusce est, rutrum lacus magna nunc vulputate interdum lorem. ipsum feugiat sagittis ornare leo aliquet nulla sapien, senectus sed rhoncus nec vulputate ac nec semper, platea condimentum taciti ac ultrices congue. faucibus platea porttitor litora ut blandit volutpat euismod augue integer inceptos porta nulla, purus etiam elit aenean quis congue curabitur consectetur commodo inceptos. \r\n\r\n	Sagittis aenean at mollis sodales feugiat dictumst bibendum gravida habitasse cubilia imperdiet, ad mauris auctor blandit egestas ultricies in accumsan sem dictumst. semper et imperdiet elementum molestie lorem leo class quisque taciti, feugiat consectetur velit tempus lacus senectus sagittis scelerisque, eros conubia bibendum est praesent lacus eu conubia. posuere sodales cras auctor torquent purus congue, curabitur vulputate interdum tempus class in condimentum, dictumst vestibulum curabitur ipsum rhoncus. venenatis taciti nulla velit mollis phasellus orci imperdiet metus velit nibh augue integer, erat viverra enim a ultrices platea tincidunt massa aliquet potenti nam. \r\n\r\n	Ornare tellus nunc felis pharetra sodales primis nec dictumst curabitur ad gravida neque phasellus, sem tortor commodo elementum aenean euismod dolor fusce aenean conubia aliquet porta. mauris fames aliquam accumsan hendrerit feugiat ac tempus cubilia, laoreet quam mollis facilisis sollicitudin praesent ante, vitae at lacinia diam leo interdum duis. non risus scelerisque ullamcorper neque class cras dolor placerat etiam dolor, mauris in arcu est suspendisse vitae congue posuere tellus, auctor pellentesque ut curabitur aenean diam senectus mauris eleifend. gravida mattis pharetra lectus urna nisi pretium ipsum netus pharetra erat, blandit nulla adipiscing est pulvinar mollis eget accumsan aptent tempus fringilla, quam varius primis urna suspendisse orci taciti ultricies vitae. \r\n\r\n	Netus felis tempus fermentum fames metus rutrum nibh, vel integer sem a taciti habitasse eros nostra, vitae elementum etiam elit euismod senectus. est ante lacus sit rutrum nulla aliquet facilisis hendrerit quisque quis, congue sagittis tempor adipiscing class et consectetur ipsum viverra curabitur, sapien nullam commodo proin justo fringilla euismod suspendisse lacus. consequat euismod aenean quisque est accumsan pulvinar lectus aenean nulla elementum commodo, ligula urna sapien proin imperdiet dapibus non eleifend conubia. pellentesque blandit hac facilisis potenti vulputate dictumst semper, habitasse et tempus sodales habitasse porttitor, tempus urna pretium tincidunt vel rhoncus. \r\n\r\n	Platea tempus orci nisl mollis rutrum rhoncus at dapibus, quis augue velit condimentum neque integer. ', 1, '2021-11-10 15:32:40', NULL),
(6, '1', 'Saiba quem foi Napoleon Hill', '	Faucibus aenean venenatis ipsum semper tortor non semper auctor elit, cubilia dolor aliquam porta eget diam blandit vitae consectetur vehicula, rutrum dui vulputate magna quisque risus torquent mi. iaculis arcu accumsan felis eros odio donec vestibulum primis tristique habitant vivamus, consectetur sit libero velit tellus aptent fringilla odio felis ligula, augue platea iaculis curae sapien egestas nam ipsum donec consequat. scelerisque congue dolor aenean dui phasellus scelerisque netus nullam molestie orci aenean nulla, venenatis facilisis eu convallis curabitur etiam nisi conubia fermentum nibh venenatis, vulputate varius donec quisque commodo class cursus congue curabitur eros posuere. \n\n	Eleifend bibendum aliquet lectus egestas elit tempus venenatis lorem enim porta maecenas, pharetra egestas integer feugiat mattis gravida purus odio condimentum feugiat, pellentesque ligula pharetra adipiscing eu ipsum scelerisque nam proin morbi. ut justo pellentesque diam nibh eget tempus, cras laoreet fermentum convallis posuere ornare, nibh ligula aenean hac est. vestibulum ut turpis elit volutpat aptent congue orci tempus consectetur, phasellus ipsum vivamus hendrerit non platea donec taciti rhoncus ullamcorper, enim dolor nam fermentum et faucibus dictumst curabitur. convallis tempus semper risus suscipit quam integer dui ut elementum, placerat pretium curae risus nec porttitor egestas cursus. \n\n	Blandit pretium himenaeos purus vitae himenaeos velit lacinia viverra cursus, rhoncus venenatis mauris mi ullamcorper curae diam phasellus, est vestibulum semper etiam sagittis turpis velit lacus. taciti faucibus leo mollis massa mi potenti, torquent erat sodales odio mattis, nunc hac himenaeos sapien risus. ornare tempor tempus rutrum euismod a sem diam porttitor, vulputate semper maecenas lectus nam velit taciti. fusce felis scelerisque dapibus mollis dui augue etiam, euismod mauris lacinia ac blandit sed, faucibus suscipit platea duis rutrum habitant. condimentum lorem aliquam dictumst venenatis leo rutrum fermentum, tristique euismod luctus scelerisque dictum curae, sociosqu habitasse lorem elementum enim egestas. \n\n	Amet tincidunt faucibus etiam id mollis sagittis sed dolor placerat nisi pulvinar aliquam cras, consequat tempus pellentesque felis urna sem auctor ad elit magna curabitur pulvinar. quisque cras quam commodo cras nisl massa praesent, vitae phasellus nunc arcu inceptos proin lacus vivamus, nam bibendum quisque accumsan hendrerit adipiscing. vehicula turpis vitae turpis vehicula purus varius ullamcorper sit tristique cras luctus erat, mollis torquent euismod eu accumsan vestibulum a est leo platea torquent nam, auctor fringilla duis vestibulum mi fusce mi hendrerit habitant leo luctus. venenatis nostra eleifend suspendisse ultrices vitae nullam porttitor convallis, pharetra phasellus pretium urna egestas donec erat. \n\n	Quam sit ante curabitur, pharetra dapibus dictumst vivamus, pellentesque dictum. ', 1, '2021-11-10 15:33:28', '2021-11-10 15:32:51');

-- --------------------------------------------------------

--
-- Estrutura da tabela `UsuariosAdmin`
--

CREATE TABLE `UsuariosAdmin` (
  `id` int NOT NULL COMMENT 'Id do usuário',
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT 'Status do usuário. 1 = Ativado, 0 = Desativado',
  `usuario` varchar(32) NOT NULL COMMENT 'Usuário utilizado para autenticação',
  `hashSenha` varchar(256) NOT NULL COMMENT 'Senha salva em formato HASH',
  `nome` varchar(32) NOT NULL COMMENT 'Nome do usuário',
  `sobrenome` varchar(64) DEFAULT NULL COMMENT 'Sobrenome do usuário',
  `email` varchar(256) DEFAULT NULL COMMENT 'Email do usuário. A RFC 5321 (MAX 256 Carac.)',
  `genero` enum('M','F','NM') NOT NULL COMMENT 'Gênero. M = Masculino, F = Feminino, NF = Não Mencionado',
  `dataCad` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data em que o registro foi cadastrado',
  `dataAt` datetime DEFAULT NULL COMMENT 'Data em que o registro foi atualizado',
  `sesAtivaCod` varchar(64) DEFAULT NULL COMMENT 'Caso o usuário esteja com alguma sessão ativa. Neste campo ficará o código. (modelo simplificado anexado)',
  `sesAtivaDtIni` datetime DEFAULT NULL COMMENT 'Data em que o usuário abriu a sessão. (modelo simplificado anexado)',
  `sesAtivaDtUp` datetime DEFAULT NULL COMMENT 'Última data em que o usuário movimentou a sessão. (modelo simplificado anexado)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `UsuariosAdmin`
--

INSERT INTO `UsuariosAdmin` (`id`, `status`, `usuario`, `hashSenha`, `nome`, `sobrenome`, `email`, `genero`, `dataCad`, `dataAt`, `sesAtivaCod`, `sesAtivaDtIni`, `sesAtivaDtUp`) VALUES
(1, '1', 'myller', 'f47fe10013d8d2fbb2f8389416999db19f76ab2249eac8970406449f7fb9c4cc14ed921f4efc0c3ae2d2421b2d330d1b6952ebad26c0e2057d4aa583a707e943', 'Myller', 'V', 'myller@example.con', 'M', '2021-11-10 15:25:32', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `UsuariosSite`
--

CREATE TABLE `UsuariosSite` (
  `id` int NOT NULL COMMENT 'Id do usuário',
  `usuario` varchar(32) NOT NULL COMMENT 'Usuário utilizado para autenticação',
  `hashSenha` varchar(256) NOT NULL COMMENT 'Senha salva em formato HASH',
  `nome` varchar(32) NOT NULL COMMENT 'Nome do usuário',
  `sobrenome` varchar(64) DEFAULT NULL COMMENT 'Sobrenome do usuário',
  `email` varchar(256) DEFAULT NULL COMMENT 'Email do usuário. A RFC 5321 (MAX 256 Carac.)',
  `genero` enum('M','F','NM') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Gênero. M = Masculino, F = Feminino, NM = Não Mencionado',
  `dataCad` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data em que o registro foi cadastrado',
  `dataAt` datetime DEFAULT NULL COMMENT 'Data em que o registro foi atualizado',
  `sesAtivaCod` varchar(64) DEFAULT NULL COMMENT 'Caso o usuário esteja com alguma sessão ativa. Neste campo ficará o código. (modelo simplificado anexado)',
  `sesAtivaDtIni` datetime DEFAULT NULL COMMENT 'Data em que o usuário abriu a sessão. (modelo simplificado anexado)',
  `sesAtivaDtUp` datetime DEFAULT NULL COMMENT 'Última data em que o usuário movimentou a sessão. (modelo simplificado anexado)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `UsuariosSite`
--

INSERT INTO `UsuariosSite` (`id`, `usuario`, `hashSenha`, `nome`, `sobrenome`, `email`, `genero`, `dataCad`, `dataAt`, `sesAtivaCod`, `sesAtivaDtIni`, `sesAtivaDtUp`) VALUES
(3, 'paulo', 'e3b9fdf2bd5890c5c751a7ed40e518feddcb8ee9b266073ad56482fdc999a63a5ddd2e33c5c3188f9df26150b6b85fa944461eb9d7a887203a5e88193fc2f6d7', 'Paulo', 'Alves de Brito', 'paulo.brito.eletro@hotmail.com', 'M', '2021-11-11 16:52:09', NULL, NULL, NULL, NULL),
(4, 'lucas', 'e3b9fdf2bd5890c5c751a7ed40e518feddcb8ee9b266073ad56482fdc999a63a5ddd2e33c5c3188f9df26150b6b85fa944461eb9d7a887203a5e88193fc2f6d7', 'Lucas', 'Afonso da Silva', 'lucas@hotmail.com', 'M', '2021-11-11 17:23:21', NULL, NULL, NULL, NULL),
(5, 'jucapereira', '579f8dde5966f7381ae1402bf7f547a8b8c3f8e23a25edc6caec05e38729206460750673a1b02fb06e7122cd62951bfebcd39f10512529a39b1584fbcff76e2d', 'Juca', 'Lafonso Pereira', 'juca@example.com', 'F', '2021-11-11 17:26:20', NULL, NULL, NULL, NULL),
(6, 'marcone', '579f8dde5966f7381ae1402bf7f547a8b8c3f8e23a25edc6caec05e38729206460750673a1b02fb06e7122cd62951bfebcd39f10512529a39b1584fbcff76e2d', 'Marcone', 'Felizberto', 'marcone@hotmail.com', 'NM', '2021-11-11 17:37:01', NULL, NULL, NULL, NULL),
(7, 'luzia', 'dd6eca5cee4f8bfa94638ed7973e3a5ceb6be4ad62d4f6509836bd0f4bbdbd544694effd25afc8aad91079419a8743e86df818c587f50063b1760c3ab060811a', 'Luzia', 'Abrantes Regis', 'luzia@hotmail.com', 'F', '2021-11-11 17:39:21', NULL, NULL, NULL, NULL),
(8, 'abelpereira', 'f75321faead15e8bffd727ab2154d16f70dd2ba233ff6dd70a3a19798652064825ee2797f260098c9097c3156701d201b7d958781088028b60037cbf16ab9b0e', 'Abel', 'Afonso Pereira', 'abel@abel.com', 'M', '2021-11-11 17:40:24', NULL, NULL, NULL, NULL),
(9, 'ilvacunha', '16f96e91106b0b825e560b0186b179906f04cd563b5390131c0df952b2802c68abab67485c458f56b710ebcb7d6f872b13161a8cb21e579c6b60aee1e1d07626', 'Ilva', 'Cunha da Silva', 'ilva@hotmail.com.br', 'M', '2021-11-11 18:59:07', NULL, NULL, '2021-11-12 05:04:29', NULL),
(11, 'josealves', '58eff8abf475fca305bb5b6b55459c994d37d20ce55e7f186d313b1185dcf72da472f3c17e42cb96192c0d6711f5d6d4d804cf2916c3b16d6fae8c1dd2676e9d', 'Jose', 'Alves da Silva', 'jose@hotmail.com', 'M', '2021-11-12 15:34:35', NULL, NULL, '2021-11-12 16:25:46', '2021-11-12 16:33:10'),
(13, 'marcus', '58eff8abf475fca305bb5b6b55459c994d37d20ce55e7f186d313b1185dcf72da472f3c17e42cb96192c0d6711f5d6d4d804cf2916c3b16d6fae8c1dd2676e9d', 'Marcus', 'Pereira', 'marcus@hotmail.com', 'M', '2021-11-12 16:49:07', NULL, 'e33880T07971z8IU54G29O26522j1P0P', '2021-11-12 16:49:43', '2021-11-12 16:49:57');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `ComentariosPosts`
--
ALTER TABLE `ComentariosPosts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUsSite` (`idUsSite`),
  ADD KEY `idUsAdmin` (`idUsAdmin`);

--
-- Índices para tabela `Permissoes`
--
ALTER TABLE `Permissoes`
  ADD PRIMARY KEY (`codigo`);

--
-- Índices para tabela `PermissoesUsuariosAdmin`
--
ALTER TABLE `PermissoesUsuariosAdmin`
  ADD PRIMARY KEY (`idUsuario`,`codigo`),
  ADD KEY `codigo` (`codigo`);

--
-- Índices para tabela `Posts`
--
ALTER TABLE `Posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `idUsuario` (`idUsuario`);

--
-- Índices para tabela `UsuariosAdmin`
--
ALTER TABLE `UsuariosAdmin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD UNIQUE KEY `sesAtivaCod` (`sesAtivaCod`),
  ADD KEY `status` (`status`);

--
-- Índices para tabela `UsuariosSite`
--
ALTER TABLE `UsuariosSite`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD UNIQUE KEY `sesAtivaCod` (`sesAtivaCod`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `ComentariosPosts`
--
ALTER TABLE `ComentariosPosts`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'Id do comentário';

--
-- AUTO_INCREMENT de tabela `Posts`
--
ALTER TABLE `Posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT COMMENT 'Id da postagem', AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `UsuariosAdmin`
--
ALTER TABLE `UsuariosAdmin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT COMMENT 'Id do usuário', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `UsuariosSite`
--
ALTER TABLE `UsuariosSite`
  MODIFY `id` int NOT NULL AUTO_INCREMENT COMMENT 'Id do usuário', AUTO_INCREMENT=14;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `ComentariosPosts`
--
ALTER TABLE `ComentariosPosts`
  ADD CONSTRAINT `ComentariosPosts_ibfk_1` FOREIGN KEY (`idUsSite`) REFERENCES `UsuariosSite` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ComentariosPosts_ibfk_2` FOREIGN KEY (`idUsAdmin`) REFERENCES `UsuariosAdmin` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `PermissoesUsuariosAdmin`
--
ALTER TABLE `PermissoesUsuariosAdmin`
  ADD CONSTRAINT `PermissoesUsuariosAdmin_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `UsuariosAdmin` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `PermissoesUsuariosAdmin_ibfk_2` FOREIGN KEY (`codigo`) REFERENCES `Permissoes` (`codigo`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `Posts`
--
ALTER TABLE `Posts`
  ADD CONSTRAINT `Posts_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `UsuariosAdmin` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
