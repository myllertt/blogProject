-- MySQL dump 10.13  Distrib 8.0.27, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: blogProject
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Permissoes`
--

DROP TABLE IF EXISTS `Permissoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Permissoes` (
  `codigo` varchar(64) NOT NULL COMMENT 'Código de referência da permissão.',
  `descricao` varchar(128) DEFAULT NULL COMMENT 'Descrição da permissão.',
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permissoes`
--

LOCK TABLES `Permissoes` WRITE;
/*!40000 ALTER TABLE `Permissoes` DISABLE KEYS */;
INSERT INTO `Permissoes` VALUES ('mconta_altsenha','Minha Conta / Alterar Senha'),('mconta_editcad','Minha Conta / Editar Cadastro'),('mconta_excl','Minha Conta / Excluir'),('posts_editar','Posts / Editar'),('posts_excl','Posts / Excluir'),('posts_listar','Posts / Listar'),('posts_postar','Posts / Postar'),('sistema_backups','Sistema / Backups'),('sistema_backups_download','Sistema / Backups / Downlaod'),('users_cad','Usuários / Cadastrar'),('users_editcad','Usuários / Editar Cadastro'),('users_editperms','Usuários / Editar Permissões'),('users_excl','Usuários / Excluir Cadastro'),('users_listar','Usuários / Listar'),('users_redefsenha','Usuários / Redefinir Senha');
/*!40000 ALTER TABLE `Permissoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PermissoesUsuariosAdmin`
--

DROP TABLE IF EXISTS `PermissoesUsuariosAdmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PermissoesUsuariosAdmin` (
  `idUsuario` int NOT NULL COMMENT '(Relação com a tabela. UsuariosAdmin.id) Id do usuário admin',
  `codigo` varchar(64) NOT NULL COMMENT '(Relação com a tabela. Permissoes.codigo) Codigo respectivo da permissão',
  PRIMARY KEY (`idUsuario`,`codigo`),
  KEY `codigo` (`codigo`),
  CONSTRAINT `PermissoesUsuariosAdmin_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `UsuariosAdmin` (`id`) ON DELETE CASCADE,
  CONSTRAINT `PermissoesUsuariosAdmin_ibfk_2` FOREIGN KEY (`codigo`) REFERENCES `Permissoes` (`codigo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PermissoesUsuariosAdmin`
--

LOCK TABLES `PermissoesUsuariosAdmin` WRITE;
/*!40000 ALTER TABLE `PermissoesUsuariosAdmin` DISABLE KEYS */;
INSERT INTO `PermissoesUsuariosAdmin` VALUES (17,'mconta_altsenha'),(18,'mconta_altsenha'),(17,'mconta_editcad'),(18,'mconta_editcad'),(17,'mconta_excl'),(18,'mconta_excl'),(17,'posts_editar'),(18,'posts_editar'),(18,'posts_excl'),(17,'posts_listar'),(18,'posts_listar'),(17,'posts_postar'),(18,'posts_postar'),(18,'sistema_backups'),(18,'sistema_backups_download'),(18,'users_cad'),(18,'users_editcad'),(18,'users_editperms'),(18,'users_excl'),(18,'users_listar'),(18,'users_redefsenha');
/*!40000 ALTER TABLE `PermissoesUsuariosAdmin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Posts`
--

DROP TABLE IF EXISTS `Posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Posts` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Id da postagem',
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT 'Status da postagem. 1 = Ativado, 0 = Desativado',
  `titulo` varchar(128) NOT NULL COMMENT 'Título da postagem',
  `conteudo` text NOT NULL COMMENT 'Conteúdo da postagem',
  `idUsuario` int NOT NULL COMMENT '(Relação com a tabela. UsuariosAdmin.id). Id do usuário responsável pela postagem.',
  `dataCad` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data em que o registro foi cadastrado',
  `dataAt` datetime DEFAULT NULL COMMENT 'Data em que o registro foi atualizado',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `idUsuario` (`idUsuario`),
  CONSTRAINT `Posts_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `UsuariosAdmin` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Posts`
--

LOCK TABLES `Posts` WRITE;
/*!40000 ALTER TABLE `Posts` DISABLE KEYS */;
INSERT INTO `Posts` VALUES (22,'1','Nova Tecnologia','Lorem ipsum gravida quis sagittis suscipit quis placerat nisl platea vitae, sapien gravida habitasse egestas rutrum at fringilla ante iaculis sed, sagittis mattis donec tristique nec bibendum ullamcorper ac cras. imperdiet sed etiam sem scelerisque blandit proin phasellus venenatis, fermentum nec taciti egestas sed erat tellus aliquam, mauris nulla porttitor luctus curae habitant platea. diam integer feugiat lacinia aliquam conubia rutrum, velit mattis aliquet mattis scelerisque, taciti blandit eu felis auctor. fusce volutpat fermentum erat non porta fermentum neque iaculis malesuada arcu ut odio quis, sed nisi aliquet accumsan magna rutrum amet aenean curabitur sociosqu massa torquent, molestie vehicula eleifend himenaeos pellentesque porta curae erat tincidunt leo diam rutrum. \r\n\r\n	Lectus platea aliquam enim quisque ante nostra nullam etiam, habitasse primis himenaeos lorem fames rutrum ultrices ligula, litora curabitur fames sociosqu ultrices vulputate semper. fusce eleifend ornare luctus tincidunt, tortor porta euismod id elit, urna torquent magna. scelerisque nam lectus habitant lacinia volutpat vehicula conubia class molestie ornare malesuada praesent taciti ultricies, augue pulvinar nisl suspendisse quisque sociosqu laoreet rhoncus volutpat tristique nunc eleifend. pretium sapien ultricies iaculis id magna augue ad justo, gravida ipsum sit curabitur porttitor phasellus litora, fringilla lorem auctor ac morbi et nunc. ipsum elementum nec dictumst consequat suspendisse bibendum mauris neque dictumst class, fringilla nec aliquam interdum libero luctus per laoreet lorem cras, curabitur etiam dictum potenti condimentum nulla bibendum sodales facilisis. \r\n\r\n	Sit gravida donec lorem etiam integer ante vestibulum, taciti vehicula lectus class dictumst potenti aliquam congue, imperdiet primis donec senectus consequat enim. malesuada lobortis dolor feugiat eget lobortis augue vehicula donec sapien, a pretium litora cras placerat cras litora blandit, metus morbi maecenas fames porta sollicitudin fames potenti. donec felis metus integer platea dui sed risus interdum ultricies, odio platea eu curae auctor ornare tristique consequat, aliquet a fermentum etiam adipiscing enim dui erat.',19,'2021-11-22 17:48:16',NULL),(23,'1','Novidades do Flutter','Lorem ipsum morbi dictumst nisi tortor quam, est proin gravida donec habitant, ullamcorper suspendisse ligula odio sollicitudin. leo lobortis quisque vehicula primis habitant lacinia diam ornare class aliquet quisque, malesuada viverra consectetur dictum id curae lectus litora non. blandit diam cras id nisi leo amet volutpat vehicula placerat, mattis nec pellentesque velit bibendum eget vehicula est, imperdiet quisque diam turpis elit aenean tincidunt viverra. euismod ante est faucibus porta curabitur feugiat, pretium augue commodo duis purus, lectus iaculis sem integer erat. pulvinar inceptos imperdiet bibendum adipiscing hac neque malesuada viverra cubilia molestie sociosqu vehicula augue ultricies, velit arcu curabitur aliquam leo iaculis quis tempus primis nostra a nunc. \r\n\r\n	Consequat mauris egestas faucibus dictumst fames dapibus lacus ante metus, lacus per dolor eu donec blandit eu senectus sagittis netus, eu augue blandit felis eu turpis erat ullamcorper. quam curae ante scelerisque pretium nam condimentum primis, dapibus euismod lacus viverra eleifend dictumst justo, aenean varius felis suspendisse feugiat pharetra. tempor hac lorem donec ultrices donec eget viverra accumsan nisl, aenean rutrum fermentum condimentum tempus vehicula id hac, id interdum platea metus cubilia pellentesque at etiam. sollicitudin sem hendrerit mattis consequat pellentesque imperdiet tincidunt condimentum at, ultricies justo vivamus a cras velit platea senectus faucibus, tellus adipiscing semper cubilia ad netus eleifend malesuada. \r\n\r\n	Dui leo molestie est nullam turpis eros facilisis tempor vehicula phasellus consequat platea, condimentum vivamus elementum adipiscing condimentum vitae nulla nibh vestibulum lectus. dictumst sagittis per erat ante in lacinia, mollis consectetur curabitur malesuada leo sodales litora, elit sollicitudin molestie class platea. risus iaculis nec faucibus placerat mollis sem quisque donec torquent litora mi, hac eros elementum etiam habitant ante quam suscipit laoreet lorem, sollicitudin lacus leo cursus ut ullamcorper pellentesque senectus etiam elementum. cubilia augue feugiat pulvinar mattis malesuada, imperdiet fusce eget nunc senectus aenean, massa tellus ullamcorper ultricies.',19,'2021-11-22 17:48:47',NULL),(24,'1','O Provável futuro de Wall Street','Lorem ipsum vitae euismod potenti nam, velit semper aenean. eleifend cubilia id magna enim accumsan fusce varius, sed ultrices vehicula est sociosqu lobortis nec class, libero sagittis et eu nisl ipsum. curabitur aenean eget facilisis ultrices turpis feugiat vehicula quam, phasellus inceptos tristique cursus ultricies etiam tortor, hac conubia sagittis faucibus risus nulla aliquam ligula, netus luctus in commodo cras faucibus. senectus molestie nibh rutrum ante porta vehicula sed vivamus nullam sit euismod eros, a nec litora odio nulla condimentum interdum tempor justo urna neque. adipiscing erat velit sit phasellus sem id blandit aliquam, donec fames congue turpis vivamus tortor ad euismod, et tortor blandit luctus sem massa turpis. \r\n\r\n	Iaculis curabitur elementum vehicula ipsum nibh phasellus, pretium tempus tristique fames neque etiam enim, sed nisi eleifend convallis primis. dictum ultricies tristique torquent rhoncus dapibus consequat sapien quam, quisque in fermentum luctus morbi platea conubia tincidunt, rutrum dictum justo convallis donec netus porttitor. amet ligula mattis lectus ligula dolor vulputate fermentum, fames proin tellus commodo gravida nam luctus, sit duis donec sit sapien felis. velit blandit ad nibh faucibus potenti vitae auctor tempor, sollicitudin dictum consectetur posuere ante diam in nulla, duis primis inceptos fringilla volutpat aenean nullam. cursus quam risus potenti rhoncus per hac nisl ullamcorper sagittis, tortor taciti curabitur bibendum semper sed per proin donec, commodo diam litora sollicitudin primis mollis lectus sagittis. \r\n\r\n	Sit mattis odio inceptos class facilisis dolor pulvinar ipsum lorem habitant vestibulum elit, orci molestie eleifend mattis per dictumst purus nibh id pulvinar. neque himenaeos etiam porttitor nostra tempor a, blandit ut libero egestas litora ac, est nam semper imperdiet suspendisse euismod, sollicitudin consequat morbi consectetur ornare. ad quam torquent a platea egestas commodo pharetra, pulvinar iaculis porta ipsum dapibus nibh interdum pellentesque, sodales dictum sit in at dapibus. primis interdum erat ad taciti, facilisis elit.',18,'2021-11-22 17:56:39',NULL),(25,'1','Saiba quem foi Napoleon Hill','Lorem ipsum morbi tortor aliquam facilisis imperdiet fringilla himenaeos semper tortor, pulvinar tempor iaculis vel enim rhoncus fames risus nisi enim vitae, consequat proin amet tincidunt purus class rutrum hac ut. lacus nostra tincidunt lectus conubia venenatis vehicula donec sem sollicitudin ad ultrices, integer curae eu aliquam id diam pretium hac commodo morbi. phasellus et leo nunc bibendum et nullam sem class, vivamus id aliquam vitae habitasse tincidunt praesent, libero cras convallis suspendisse cras luctus velit. posuere ante lobortis amet massa maecenas nibh consectetur, curabitur neque vestibulum adipiscing et maecenas, at auctor pretium duis ornare vel. \r\n\r\n	Facilisis venenatis arcu suscipit per justo ullamcorper convallis egestas orci litora conubia elementum, potenti molestie donec vehicula eu inceptos molestie aliquam sagittis dapibus iaculis, curae quisque neque purus conubia nec neque fames pellentesque egestas lacus. condimentum risus et ut conubia integer pharetra fringilla vivamus pretium, hac phasellus duis mattis nostra dolor nullam proin ante, netus velit auctor in risus bibendum vel ipsum. felis vulputate massa potenti nisi interdum mattis dolor, tortor lobortis integer hac id etiam volutpat porta, taciti orci laoreet arcu vivamus quisque. mi erat auctor eget consectetur vestibulum vitae integer euismod aliquet habitant, a consectetur odio commodo est ultricies varius molestie netus aliquam platea, sodales primis tellus suscipit nulla vehicula sodales fermentum sed. \r\n\r\n	Odio vulputate etiam nunc habitant rutrum commodo tellus, ut iaculis inceptos augue curabitur ante per congue, dolor fringilla tortor nulla pulvinar adipiscing. netus habitasse class suspendisse porta semper mollis pellentesque eleifend tristique litora felis, non curabitur ligula laoreet curabitur tortor ultrices imperdiet platea justo, aptent semper ligula nulla fermentum cursus donec lacus malesuada tincidunt. lobortis consectetur imperdiet orci suscipit urna ullamcorper fusce sem nullam curabitur, feugiat ullamcorper sociosqu etiam suspendisse class phasellus posuere aenean ultrices accumsan, sapien mi ultricies nunc aliquam porta neque fusce aliquet. platea magna orci, eget.',18,'2021-11-22 17:57:21',NULL),(26,'1','Novidades do mundo da programação','Lorem ipsum iaculis neque erat taciti ultrices pellentesque aenean, metus eros felis mollis arcu magna imperdiet quisque pretium, non potenti morbi platea mollis malesuada aliquet. feugiat aenean sem neque commodo enim ac, pellentesque congue bibendum aenean blandit accumsan blandit, id varius pellentesque convallis ante. id ultrices etiam conubia sodales velit cursus malesuada, quis habitasse sit metus nam malesuada cras eu, donec vestibulum mollis enim donec elementum. sociosqu nostra donec tortor blandit pulvinar metus dictum facilisis feugiat, lorem feugiat netus id vestibulum elementum congue ornare donec fusce, convallis fusce ultricies lacinia mollis ipsum scelerisque in. \r\n\r\n	A facilisis quis nam ultrices ac adipiscing pretium, nisi praesent ut sociosqu maecenas. consectetur risus tempus tempor ut torquent cursus turpis eget ipsum, odio ligula per sem rutrum laoreet posuere fringilla in consequat, nullam ligula morbi augue in amet augue fusce. donec commodo sociosqu nisl taciti aliquam aenean vitae ante pretium lacus, elit non orci inceptos convallis et habitant porttitor habitant ipsum, curabitur ornare massa magna aliquam maecenas porta senectus adipiscing. torquent vel eget volutpat tristique facilisis interdum malesuada erat porttitor vehicula, ligula semper ut proin conubia tempus vivamus ultrices rhoncus semper donec, id vulputate tortor maecenas sodales justo mauris consequat facilisis. \r\n\r\n	Fames metus congue augue cursus viverra odio aliquam rutrum risus sollicitudin libero, ligula cursus quisque aliquam faucibus proin ut nulla et libero. dolor conubia auctor donec sed vehicula tortor massa hac, suspendisse nostra est odio blandit sagittis venenatis integer tempus, cubilia quisque maecenas tincidunt venenatis nisi bibendum. placerat lacinia consectetur massa pellentesque hendrerit ullamcorper curabitur eleifend est, fames scelerisque suscipit dui leo aliquet mi sit magna imperdiet, ultrices elementum aliquam sapien justo leo id vitae. vulputate eleifend ad lacus elit eu metus duis cursus, sociosqu commodo nulla vel sapien aenean dictumst, inceptos feugiat enim felis etiam non bibendum. \r\n\r\n	Malesuada sed curae porttitor, dapibus nullam.',17,'2021-11-22 18:02:36',NULL),(27,'1','Panorama Geral Tecnológico','Lorem ipsum nullam quisque augue sodales turpis leo duis viverra, maecenas suspendisse bibendum risus pretium etiam lobortis viverra nullam habitasse, sed nibh nullam tristique tempor velit magna nunc. massa etiam vitae auctor rutrum maecenas euismod cras, proin eros posuere aliquam iaculis tempor sagittis elit, lorem fringilla luctus pulvinar vulputate fames. sagittis cubilia tortor porttitor nostra donec ornare eget tortor vitae placerat, dolor fermentum aptent congue ante integer lectus elementum habitasse sit aptent, metus felis cursus aenean mauris libero elementum massa praesent. justo id curae dui iaculis fringilla scelerisque urna suscipit semper dapibus facilisis congue, class metus non congue aptent varius ligula eu venenatis viverra. \r\n\r\n	Nisi justo porta nostra curae eleifend aenean velit et ipsum ultricies aliquet, taciti lectus aptent etiam at tellus nunc fames metus erat. aenean per curae curabitur litora tempus vulputate, mi cursus mi rutrum euismod aptent vitae, consequat dolor aliquet nunc eu. curae vulputate est hendrerit donec fames taciti quisque dolor, sodales cras condimentum feugiat libero facilisis tincidunt, porttitor blandit sollicitudin quam fringilla himenaeos dictumst. pharetra odio nulla non at nisi ultricies iaculis nulla dictumst, sodales scelerisque pellentesque ac varius fames arcu class nibh, inceptos aliquam vulputate orci duis scelerisque sed erat. \r\n\r\n	Ullamcorper suscipit quis ante vitae lectus ultricies sapien mi luctus, dictum ultrices nullam senectus sodales rutrum eleifend at ornare, hendrerit varius dictum mollis condimentum tempor ultricies ultrices. aenean amet adipiscing vestibulum imperdiet rutrum dui ad neque non aliquet, torquent tincidunt nisi eget tortor convallis et turpis ipsum aliquam, rhoncus mollis vulputate etiam aenean lobortis at netus nisi. tellus venenatis ligula lacinia taciti vitae per blandit, pellentesque litora a aliquam inceptos fermentum, fames auctor luctus senectus sem fermentum. in turpis class elementum duis ultrices accumsan diam viverra amet lobortis scelerisque velit euismod tincidunt, consequat donec phasellus vel duis curabitur elementum inceptos sollicitudin fames augue dictum pellentesque.',17,'2021-11-22 18:03:01',NULL);
/*!40000 ALTER TABLE `Posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UsuariosAdmin`
--

DROP TABLE IF EXISTS `UsuariosAdmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UsuariosAdmin` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Id do usuário',
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT 'Status do usuário. 1 = Ativado, 0 = Desativado',
  `usuario` varchar(32) NOT NULL COMMENT 'Usuário utilizado para autenticação',
  `hashSenha` varchar(256) NOT NULL COMMENT 'Senha salva em formato HASH',
  `nome` varchar(32) NOT NULL COMMENT 'Nome do usuário',
  `sobrenome` varchar(64) DEFAULT NULL COMMENT 'Sobrenome do usuário',
  `email` varchar(256) DEFAULT NULL COMMENT 'Email do usuário. A RFC 5321 (MAX 256 Carac.)',
  `genero` enum('M','F','NM') NOT NULL COMMENT 'Gênero. M = Masculino, F = Feminino, NF = Não Mencionado',
  `dataCad` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data em que o registro foi cadastrado',
  `dataAt` datetime DEFAULT NULL COMMENT 'Data em que o registro foi atualizado',
  `basePermsACL` enum('permitir','negar') NOT NULL DEFAULT 'permitir' COMMENT 'Base para a regra padrão do cálculo de permissões ACL',
  `sesAtivaCod` varchar(64) DEFAULT NULL COMMENT 'Caso o usuário esteja com alguma sessão ativa. Neste campo ficará o código. (modelo simplificado anexado)',
  `sesAtivaDtIni` datetime DEFAULT NULL COMMENT 'Data em que o usuário abriu a sessão. (modelo simplificado anexado)',
  `sesAtivaDtUp` datetime DEFAULT NULL COMMENT 'Última data em que o usuário movimentou a sessão. (modelo simplificado anexado)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  UNIQUE KEY `sesAtivaCod` (`sesAtivaCod`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UsuariosAdmin`
--

LOCK TABLES `UsuariosAdmin` WRITE;
/*!40000 ALTER TABLE `UsuariosAdmin` DISABLE KEYS */;
INSERT INTO `UsuariosAdmin` VALUES (16,'1','admin','58eff8abf475fca305bb5b6b55459c994d37d20ce55e7f186d313b1185dcf72da472f3c17e42cb96192c0d6711f5d6d4d804cf2916c3b16d6fae8c1dd2676e9d','Administrador','Sistema','admin@example.com.br','M','2021-11-22 17:40:16','2021-11-22 17:40:48','negar','2lPF1Sg9X7U75Zd8Fy109LD9KxW1XzPb','2021-11-22 18:25:53','2021-11-22 18:26:04'),(17,'1','marcio','58eff8abf475fca305bb5b6b55459c994d37d20ce55e7f186d313b1185dcf72da472f3c17e42cb96192c0d6711f5d6d4d804cf2916c3b16d6fae8c1dd2676e9d','Marcio','Costa','exemple@hotmail.com','M','2021-11-22 17:42:46','2021-11-22 18:02:07','permitir','6a18ngx4ve09q7vk5BbW823Wb432x5Z0','2021-11-22 18:01:51','2021-11-22 18:04:25'),(18,'1','sabrina','58eff8abf475fca305bb5b6b55459c994d37d20ce55e7f186d313b1185dcf72da472f3c17e42cb96192c0d6711f5d6d4d804cf2916c3b16d6fae8c1dd2676e9d','Sabrina','Alves','sab@example.com','F','2021-11-22 17:45:32','2021-11-22 17:45:53','permitir',NULL,'2021-11-22 17:49:15','2021-11-22 18:01:24'),(19,'1','myller','58eff8abf475fca305bb5b6b55459c994d37d20ce55e7f186d313b1185dcf72da472f3c17e42cb96192c0d6711f5d6d4d804cf2916c3b16d6fae8c1dd2676e9d','Myller','mg','myller@example.com','M','2021-11-22 17:46:24','2021-11-22 17:47:55','negar',NULL,'2021-11-22 17:48:02','2021-11-22 17:49:04');
/*!40000 ALTER TABLE `UsuariosAdmin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UsuariosSite`
--

DROP TABLE IF EXISTS `UsuariosSite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UsuariosSite` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Id do usuário',
  `usuario` varchar(32) NOT NULL COMMENT 'Usuário utilizado para autenticação',
  `hashSenha` varchar(256) NOT NULL COMMENT 'Senha salva em formato HASH',
  `nome` varchar(32) NOT NULL COMMENT 'Nome do usuário',
  `sobrenome` varchar(64) DEFAULT NULL COMMENT 'Sobrenome do usuário',
  `email` varchar(256) DEFAULT NULL COMMENT 'Email do usuário. A RFC 5321 (MAX 256 Carac.)',
  `genero` enum('M','F','NM') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Gênero. M = Masculino, F = Feminino, NM = Não Mencionado',
  `dataCad` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data em que o registro foi cadastrado',
  `dataAt` datetime DEFAULT NULL COMMENT 'Data em que o registro foi atualizado',
  `sesAtivaCod` varchar(64) DEFAULT NULL COMMENT 'Caso o usuário esteja com alguma sessão ativa. Neste campo ficará o código. (modelo simplificado anexado)',
  `sesAtivaDtIni` datetime DEFAULT NULL COMMENT 'Data em que o usuário abriu a sessão. (modelo simplificado anexado)',
  `sesAtivaDtUp` datetime DEFAULT NULL COMMENT 'Última data em que o usuário movimentou a sessão. (modelo simplificado anexado)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  UNIQUE KEY `sesAtivaCod` (`sesAtivaCod`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UsuariosSite`
--

LOCK TABLES `UsuariosSite` WRITE;
/*!40000 ALTER TABLE `UsuariosSite` DISABLE KEYS */;
INSERT INTO `UsuariosSite` VALUES (4,'lucas','e3b9fdf2bd5890c5c751a7ed40e518feddcb8ee9b266073ad56482fdc999a63a5ddd2e33c5c3188f9df26150b6b85fa944461eb9d7a887203a5e88193fc2f6d7','Lucas','Afonso da Silva','lucas@hotmail.com','M','2021-11-21 17:23:21',NULL,NULL,NULL,NULL),(13,'marcus','58eff8abf475fca305bb5b6b55459c994d37d20ce55e7f186d313b1185dcf72da472f3c17e42cb96192c0d6711f5d6d4d804cf2916c3b16d6fae8c1dd2676e9d','Marcus1','Pereira1','marcus@hotmail.com1','F','2021-11-21 16:49:07',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `UsuariosSite` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-22 18:26:04
